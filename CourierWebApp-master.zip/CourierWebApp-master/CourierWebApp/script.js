let currentUser = null;
let data = {};

window.onload = async function () {
  await fetchData();
  populateEmployeeSelect();
};

async function fetchData() {
  const res = await fetch("/data");
  data = await res.json();
}

function populateEmployeeSelect() {
  const select = document.getElementById("employeeSelect");
  select.innerHTML = "";
  data.employees.forEach(e => {
    const option = document.createElement("option");
    option.value = e.id;
    option.textContent = `${e.name} (${e.role})`;
    select.appendChild(option);
  });
}

function login() {
  const id = parseInt(document.getElementById("employeeSelect").value);
  currentUser = data.employees.find(e => e.id === id);
  document.getElementById("loginSection").classList.add("hidden");
  document.getElementById("navPanel").classList.remove("hidden");
  document.getElementById("currentEmployeeName").textContent = currentUser.name;

  showOrders();

  if (currentUser.role === "Администратор") {
    document.getElementById("productsTab").classList.remove("hidden");
    document.getElementById("salesTab").classList.remove("hidden");
    document.getElementById("reportsTab").classList.remove("hidden");
  }
}

function logout() {
  currentUser = null;
  document.getElementById("loginSection").classList.remove("hidden");
  document.getElementById("navPanel").classList.add("hidden");
  hideAllSections();
}

function hideAllSections() {
  document.getElementById("ordersSection").classList.add("hidden");
  document.getElementById("productsSection").classList.add("hidden");
  document.getElementById("salesSection").classList.add("hidden");
  document.getElementById("reportsSection").classList.add("hidden");
}

function showOrders() {
  hideAllSections();
  document.getElementById("ordersSection").classList.remove("hidden");
  renderFilters();
  renderOrders();
}

function showProducts() {
  hideAllSections();
  document.getElementById("productsSection").classList.remove("hidden");
  renderProducts();
}

function showSales() {
  hideAllSections();
  document.getElementById("salesSection").classList.remove("hidden");
  renderSalesForm();
}

function showReports() {
  hideAllSections();
  document.getElementById("reportsSection").classList.remove("hidden");
  document.getElementById("reportOutput").innerHTML = "";
}

function renderFilters() {
  const storeFilter = document.getElementById("storeFilter");
  const statusFilter = document.getElementById("statusFilter");
  const employeeFilter = document.getElementById("employeeFilter");

  storeFilter.innerHTML = '<option value="">Все</option>';
  data.stores.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.name;
    storeFilter.appendChild(opt);
  });

  employeeFilter.innerHTML = '<option value="">Все</option>';
  data.employees.forEach(e => {
    const opt = document.createElement("option");
    opt.value = e.id;
    opt.textContent = e.name;
    employeeFilter.appendChild(opt);
  });
}

function renderOrders() {
  const list = document.getElementById("orderList");
  list.innerHTML = "";

  const storeFilter = document.getElementById("storeFilter").value;
  const statusFilter = document.getElementById("statusFilter").value;
  const employeeFilter = document.getElementById("employeeFilter").value;

  const filteredOrders = data.orders.filter(order => {
    if (storeFilter && order.storeId != storeFilter) return false;
    if (statusFilter && order.status !== statusFilter) return false;
    if (employeeFilter) {
      const id = parseInt(employeeFilter);
      return order.collectorId === id || order.courierId === id;
    }
    return true;
  });

  filteredOrders.forEach(order => {
    const store = data.stores.find(s => s.id === order.storeId);
    const collector = data.employees.find(e => e.id === order.collectorId);
    const courier = data.employees.find(e => e.id === order.courierId);

    const card = document.createElement("div");
    card.className = "order-card";

    // Выделение просроченных
    if (order.deliveryDate && order.status !== "Доставлен") {
      const today = new Date().toISOString().split("T")[0];
      if (order.deliveryDate < today) {
        card.style.borderColor = "red";
      }
    }

    const fields = [];

    if (order.customer) fields.push(`<p><strong>Клиент:</strong> ${order.customer}</p>`);
    if (store) fields.push(`<p><strong>Магазин:</strong> ${store.name}</p>`);
    if (order.address) fields.push(`<p><strong>Адрес:</strong> ${order.address}</p>`);
    if (order.deliveryDate) fields.push(`<p><strong>Дата доставки:</strong> ${order.deliveryDate}</p>`);
    if (collector) fields.push(`<p><strong>Сборщик:</strong> ${collector.name}</p>`);
    if (courier) fields.push(`<p><strong>Курьер:</strong> ${courier.name}</p>`);
    if (order.comment) fields.push(`<p><strong>Комментарий:</strong> ${order.comment}</p>`);
    fields.push(`<p><strong>Статус:</strong> ${order.status}</p>`);

    card.innerHTML = `<h3>Заказ №${order.id}</h3>` + fields.join("");

    const currentId = currentUser?.id;
    const role = currentUser?.role;

    if (role === "Сборщик" && order.collectorId === currentId && order.status === "Новый") {
      const btn = document.createElement("button");
      btn.textContent = "Отметить как собран";
      btn.onclick = () => updateOrderStatus(order.id, "Собран");
      card.appendChild(btn);
    }

    if (role === "Курьер" && order.courierId === currentId && order.status === "Собран") {
      const btn = document.createElement("button");
      btn.textContent = "Отметить как доставлен";
      btn.onclick = () => updateOrderStatus(order.id, "Доставлен");
      card.appendChild(btn);
    }

    list.appendChild(card);
  });

  if (filteredOrders.length === 0) {
    list.innerHTML = "<p class='empty'>Заказы не найдены.</p>";
  }
}

function updateOrderStatus(orderId, newStatus) {
  const order = data.orders.find(o => o.id === orderId);
  if (order) {
    order.status = newStatus;
    sendUpdate("updateOrder", order);
    renderOrders();
  }
}

function renderProducts() {
    const container = document.getElementById("productList");
    container.innerHTML = "";
    data.products.forEach(p => {
      const imgSrc = p.image.startsWith("data:") ? p.image : `images/${p.image}`;
      const card = document.createElement("div");
      card.className = "product-card";
      card.innerHTML = `
        <img src="${imgSrc}" alt="${p.name}" />
        <p><strong>${p.name}</strong></p>
        <p>Код: ${p.code}</p>
        <p>Бренд: ${p.brand}</p>
        <p>Группа: ${p.group}</p>
        <p>Цена: ${p.price} ₽</p>
        <p>Остаток: ${p.stock}</p>
      `;
      container.appendChild(card);
    });
  }
  
  

  function addProduct() {
    const name = document.getElementById("productName").value;
    const code = document.getElementById("productCode").value;
    const brand = document.getElementById("productBrand").value;
    const group = document.getElementById("productGroup").value;
    const price = parseFloat(document.getElementById("productPrice").value);
    const stock = parseInt(document.getElementById("productStock").value);
    const file = document.getElementById("productImage").files[0];
  
    if (!name || !file || isNaN(price) || isNaN(stock)) {
      alert("Заполните все поля и выберите изображение!");
      return;
    }
  
    const reader = new FileReader();
    reader.onload = () => {
      const id = data.products.length ? Math.max(...data.products.map(p => p.id)) + 1 : 1;
      const imageBase64 = reader.result;
  
      const newProduct = {
        id,
        name,
        code,
        brand,
        group,
        price,
        stock,
        image: imageBase64
      };
  
      data.products.push(newProduct);
      sendUpdate("updateProducts", data.products);
      renderProducts();
    };
    reader.readAsDataURL(file);
  }
  

function renderSalesForm() {
  const customer = document.getElementById("saleCustomer");
  const store = document.getElementById("saleStore");
  const container = document.getElementById("saleProducts");

  customer.innerHTML = "";
  store.innerHTML = "";

  data.clients.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c.name;
    opt.textContent = c.name;
    customer.appendChild(opt);
  });

  data.stores.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.name;
    store.appendChild(opt);
  });

  container.innerHTML = "";
  addSaleItem();
}

function addSaleItem() {
  const container = document.getElementById("saleProducts");
  const div = document.createElement("div");

  const productSelect = document.createElement("select");
  data.products.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = `${p.name} — ${p.price || 0}₽ (остаток: ${p.stock || 0})`;
    productSelect.appendChild(opt);
  });

  const qty = document.createElement("input");
  qty.type = "number";
  qty.min = 1;
  qty.placeholder = "Кол-во";

  div.appendChild(productSelect);
  div.appendChild(qty);

  container.appendChild(div);
}

function submitSale() {
  const customer = document.getElementById("saleCustomer").value;
  const storeId = parseInt(document.getElementById("saleStore").value);
  const sellerId = currentUser.id;

  const items = [];
  let error = false;

  document.querySelectorAll("#saleProducts > div").forEach(div => {
    const productId = parseInt(div.querySelector("select").value);
    const quantity = parseInt(div.querySelector("input").value);
    const product = data.products.find(p => p.id === productId);
    const price = product.price;

    if (quantity > product.stock) {
      alert(`Недостаточно товара "${product.name}" на складе`);
      error = true;
      return;
    }

    if (productId && quantity && price >= 0) {
      items.push({ productId, quantity, price });
      product.stock -= quantity; // уменьшаем остаток
    }
  });

  if (error || items.length === 0) return;

  const id = data.sales.length ? Math.max(...data.sales.map(s => s.id)) + 1 : 1;
  const sale = { id, customer, storeId, sellerId, date: new Date().toISOString().split("T")[0], items };

  data.sales.push(sale);
  sendUpdate("updateSales", data.sales);
  sendUpdate("updateProducts", data.products);
  alert("Продажа успешно оформлена!");
}

function generateSalesReport() {
  const from = document.getElementById("reportFrom").value;
  const to = document.getElementById("reportTo").value;

  const filtered = data.sales.filter(sale => {
    return (!from || sale.date >= from) && (!to || sale.date <= to);
  });

  const report = filtered.map(sale => {
    const total = sale.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    return `<p><strong>${sale.customer}</strong> — ${total} ₽ (${sale.date})</p>`;
  }).join("");

  document.getElementById("reportOutput").innerHTML = `<h3>Продажи</h3>${report}`;
}

function sendUpdate(endpoint, payload) {
  fetch(`/${endpoint}`, {
    method: "POST",
    body: JSON.stringify(payload)
  });
}
