function loadProducts() {
    const container = document.getElementById('products-container');
    container.innerHTML = '';
    const products = allData.products;

    products.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product-card';

        const imageUrl = product.image ? `images/${product.image}` : 'images/default.jpg';

        div.innerHTML = `
            <img src="${imageUrl}" alt="${product.name}" class="product-image">
            <p><strong>Код:</strong> ${product.code}</p>
            <p><strong>Название:</strong> ${product.name}</p>
            <p><strong>Бренд:</strong> ${product.brand}</p>
            <p><strong>Группа:</strong> ${product.group}</p>
            <p><strong>Цена:</strong> ${product.price} ₽</p>
            <button onclick="editProduct(${product.id})">Редактировать</button>
            <button onclick="deleteProduct(${product.id})">Удалить</button>
        `;

        container.appendChild(div);
    });

    renderProductForm();
}

function renderProductForm(product = null) {
    const form = document.getElementById('product-form');
    form.innerHTML = '';

    const isEdit = product !== null;

    const id = isEdit ? product.id : Date.now();
    const code = isEdit ? product.code : '';
    const name = isEdit ? product.name : '';
    const brand = isEdit ? product.brand : '';
    const group = isEdit ? product.group : '';
    const price = isEdit ? product.price : '';
    const image = isEdit ? product.image : '';

    form.innerHTML = `
        <h3>${isEdit ? 'Редактировать' : 'Добавить'} товар</h3>
        <input type="text" placeholder="Код" id="product-code" value="${code}">
        <input type="text" placeholder="Название" id="product-name" value="${name}">
        <input type="text" placeholder="Бренд" id="product-brand" value="${brand}">
        <input type="text" placeholder="Группа" id="product-group" value="${group}">
        <input type="number" placeholder="Цена" id="product-price" value="${price}">
        <input type="file" id="product-image">
        <button onclick="${isEdit ? `saveProduct(${id})` : `addProduct(${id})`}">
            ${isEdit ? 'Сохранить изменения' : 'Добавить'}
        </button>
    `;
}

function addProduct(newId) {
    const newProduct = getProductFormData(newId);
    allData.products.push(newProduct);
    saveData();
    loadProducts();
}

function saveProduct(id) {
    const product = allData.products.find(p => p.id === id);
    const updated = getProductFormData(id);
    Object.assign(product, updated);
    saveData();
    loadProducts();
}

function deleteProduct(id) {
    if (confirm("Удалить этот товар?")) {
        allData.products = allData.products.filter(p => p.id !== id);
        saveData();
        loadProducts();
    }
}

function editProduct(id) {
    const product = allData.products.find(p => p.id === id);
    renderProductForm(product);
}

function getProductFormData(id) {
    const code = document.getElementById('product-code').value;
    const name = document.getElementById('product-name').value;
    const brand = document.getElementById('product-brand').value;
    const group = document.getElementById('product-group').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const fileInput = document.getElementById('product-image');
    const file = fileInput.files[0];
    let image = '';

    if (file) {
        image = file.name;
        // В полноценном сервере файл нужно сохранить в папку /images/
    } else {
        const existingProduct = allData.products.find(p => p.id === id);
        image = existingProduct ? existingProduct.image : 'default.jpg';
    }

    return {
        id,
        code,
        name,
        brand,
        group,
        price,
        image
    };
}
