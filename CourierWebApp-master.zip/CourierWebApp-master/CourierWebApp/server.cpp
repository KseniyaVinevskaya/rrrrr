﻿#include <winsock2.h>
#include <ws2tcpip.h>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include "json.hpp"
#pragma comment(lib, "Ws2_32.lib")

using json = nlohmann::json;

#define DEFAULT_PORT "8080"
#define BUFFER_SIZE 8192

// Чтение содержимого файла в строку
std::string readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        return "";
    }
    std::ostringstream oss;
    oss << file.rdbuf();
    return oss.str();
}

// Сохранение JSON-объекта в файл data.json с форматированием
void saveJson(const json& data) {
    std::ofstream out("data.json");
    if (!out.is_open()) {
        std::cerr << "Ошибка: не удалось открыть data.json для записи" << std::endl;
        return;
    }
    out << data.dump(2);
    out.close();
}

int main() {
    WSADATA wsaData;
    struct addrinfo* result = NULL, hints;
    SOCKET ListenSocket = INVALID_SOCKET, ClientSocket = INVALID_SOCKET;
    char recvbuf[BUFFER_SIZE];
    int recvbuflen = BUFFER_SIZE;

    // Инициализация Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "WSAStartup failed" << std::endl;
        return 1;
    }

    ZeroMemory(&hints, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = AI_PASSIVE;

    if (getaddrinfo(NULL, DEFAULT_PORT, &hints, &result) != 0) {
        std::cerr << "getaddrinfo failed" << std::endl;
        WSACleanup();
        return 1;
    }

    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        std::cerr << "Ошибка создания сокета" << std::endl;
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    if (bind(ListenSocket, result->ai_addr, (int)result->ai_addrlen) == SOCKET_ERROR) {
        std::cerr << "Ошибка bind" << std::endl;
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    freeaddrinfo(result);

    if (listen(ListenSocket, SOMAXCONN) == SOCKET_ERROR) {
        std::cerr << "Ошибка listen" << std::endl;
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    std::cout << "Сервер запущен на http://localhost:" << DEFAULT_PORT << std::endl;

    // Основной цикл обработки запросов
    while (true) {
        ClientSocket = accept(ListenSocket, NULL, NULL);
        if (ClientSocket == INVALID_SOCKET) {
            std::cerr << "Ошибка accept" << std::endl;
            continue;
        }

        // Получаем данные запроса
        int bytesReceived = recv(ClientSocket, recvbuf, recvbuflen - 1, 0);
        if (bytesReceived <= 0) {
            closesocket(ClientSocket);
            continue;
        }
        recvbuf[bytesReceived] = '\0';
        std::string request(recvbuf);

        // Парсим метод и путь из первой строки HTTP-запроса
        std::istringstream requestStream(request);
        std::string method, path;
        requestStream >> method >> path;
        std::string response;

        if (method == "GET") {
            // Обработка GET запросов

            // Главная страница и статика HTML/CSS/JS
            if (path == "/" || path == "/index.html") {
                std::string content = readFile("index.html");
                response = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: "
                    + std::to_string(content.size()) + "\r\n\r\n" + content;
            }
            else if (path == "/style.css") {
                std::string content = readFile("style.css");
                response = "HTTP/1.1 200 OK\r\nContent-Type: text/css\r\nContent-Length: "
                    + std::to_string(content.size()) + "\r\n\r\n" + content;
            }
            else if (path == "/script.js") {
                std::string content = readFile("script.js");
                response = "HTTP/1.1 200 OK\r\nContent-Type: application/javascript\r\nContent-Length: "
                    + std::to_string(content.size()) + "\r\n\r\n" + content;
            }
            else if (path == "/products.js") {
                std::string content = readFile("products.js");
                response = "HTTP/1.1 200 OK\r\nContent-Type: application/javascript\r\nContent-Length: "
                    + std::to_string(content.size()) + "\r\n\r\n" + content;
            }
            // Возврат данных (JSON)
            else if (path == "/data" || path == "/data.json") {
                std::string content = readFile("data.json");
                response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "
                    + std::to_string(content.size()) + "\r\n\r\n" + content;
            }
            // Изображения
            else if (path.rfind("/images/", 0) == 0) {
                // Убираем префикс "/images/" и пытаемся открыть файл
                std::string filename = path.substr(std::string("/images/").length());
                std::ifstream imgFile("images/" + filename, std::ios::binary);
                if (imgFile) {
                    std::ostringstream ss;
                    ss << imgFile.rdbuf();
                    std::string imgData = ss.str();
                    // Определяем MIME-тип по расширению файла
                    std::string contentType;
                    std::string ext;
                    size_t dotPos = filename.find_last_of('.');
                    if (dotPos != std::string::npos) {
                        ext = filename.substr(dotPos + 1);
                        for (char& c : ext) c = tolower(c);
                    }
                    if (ext == "png") contentType = "image/png";
                    else if (ext == "jpg" || ext == "jpeg") contentType = "image/jpeg";
                    else if (ext == "gif") contentType = "image/gif";
                    else contentType = "application/octet-stream";
                    response = "HTTP/1.1 200 OK\r\nContent-Type: " + contentType + "\r\nContent-Length: "
                        + std::to_string(imgData.size()) + "\r\n\r\n";
                    // Добавляем бинарные данные изображения к заголовкам
                    response.append(imgData.begin(), imgData.end());
                }
                else {
                    response = "HTTP/1.1 404 Not Found\r\n\r\nImage not found";
                }
            }
            else {
                // Неизвестный путь
                response = "HTTP/1.1 404 Not Found\r\n\r\nNot Found";
            }
        }
        else if (method == "POST") {
            // Обработка POST запросов
            // Извлекаем тело запроса (JSON)
            std::string body;
            size_t pos = request.find("\r\n\r\n");
            if (pos != std::string::npos) {
                body = request.substr(pos + 4);
            }

            // Обновление заказа
            if (path == "/updateOrder") {
                try {
                    json updatedOrder = json::parse(body);
                    // Загружаем текущие данные
                    std::ifstream inFile("data.json");
                    json data;
                    inFile >> data;
                    inFile.close();
                    if (!updatedOrder.is_object() || !updatedOrder.contains("id")) {
                        throw std::runtime_error("Некорректный формат заказа");
                    }
                    int orderId = updatedOrder["id"];
                    bool replaced = false;
                    // Ищем заказ с таким ID и обновляем его
                    if (data.contains("orders")) {
                        for (auto& order : data["orders"]) {
                            if (order["id"] == orderId) {
                                order = updatedOrder;
                                replaced = true;
                                break;
                            }
                        }
                    }
                    else {
                        // Если раздел orders отсутствует, создаём его
                        data["orders"] = json::array();
                    }
                    // Если не найден - добавляем как новый
                    if (!replaced) {
                        data["orders"].push_back(updatedOrder);
                    }
                    // Сохраняем файл
                    saveJson(data);
                    response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\n\r\nOK";
                    std::cout << "Обновлен заказ (ID: " << orderId;
                    if (!replaced) std::cout << ", добавлен новый";
                    std::cout << ")" << std::endl;
                }
                catch (const std::exception& ex) {
                    std::cerr << "Ошибка при обновлении заказа: " << ex.what() << std::endl;
                    response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                }
            }
            // Добавление нового товара
            else if (path == "/addProduct") {
                try {
                    json newProduct = json::parse(body);
                    // Загружаем текущие данные
                    std::ifstream inFile("data.json");
                    json data;
                    inFile >> data;
                    inFile.close();
                    if (!data.contains("products")) {
                        data["products"] = json::array();
                    }
                    // Генерируем новый уникальный ID для товара
                    int newId = 1;
                    for (const auto& prod : data["products"]) {
                        if (prod.contains("id") && prod["id"].is_number()) {
                            int existingId = prod["id"];
                            if (existingId >= newId) {
                                newId = existingId + 1;
                            }
                        }
                    }
                    newProduct["id"] = newId;
                    // Добавляем товар в массив
                    data["products"].push_back(newProduct);
                    // Сохраняем JSON в файл
                    saveJson(data);
                    response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\n\r\nOK";
                    std::cout << "Добавлен товар: "
                        << (newProduct.contains("name") ? std::string(newProduct["name"]) : "")
                        << " (ID: " << newId << ")" << std::endl;
                }
                catch (const std::exception& ex) {
                    std::cerr << "Ошибка при добавлении товара: " << ex.what() << std::endl;
                    response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                }
            }
            // Добавление новой продажи
            else if (path == "/addSale") {
                try {
                    json newSale = json::parse(body);
                    // Загружаем текущие данные
                    std::ifstream inFile("data.json");
                    json data;
                    inFile >> data;
                    inFile.close();
                    if (!data.contains("sales")) {
                        data["sales"] = json::array();
                    }
                    // Генерируем новый уникальный ID для продажи
                    int newId = 1;
                    for (const auto& sale : data["sales"]) {
                        if (sale.contains("id") && sale["id"].is_number()) {
                            int existingId = sale["id"];
                            if (existingId >= newId) {
                                newId = existingId + 1;
                            }
                        }
                    }
                    newSale["id"] = newId;
                    data["sales"].push_back(newSale);
                    saveJson(data);
                    response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\n\r\nOK";
                    std::cout << "Добавлена продажа (ID: " << newId << ")" << std::endl;
                }
                catch (const std::exception& ex) {
                    std::cerr << "Ошибка при добавлении продажи: " << ex.what() << std::endl;
                    response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                }
            }
            // Редактирование товара (обновление существующего)
            else if (path == "/updateProduct") {
                try {
                    json updatedProduct = json::parse(body);
                    std::ifstream inFile("data.json");
                    json data;
                    inFile >> data;
                    inFile.close();
                    if (!updatedProduct.is_object() || !updatedProduct.contains("id")) {
                        throw std::runtime_error("Некорректный формат товара");
                    }
                    int prodId = updatedProduct["id"];
                    if (!data.contains("products")) {
                        data["products"] = json::array();
                    }
                    for (auto& prod : data["products"]) {
                        if (prod["id"] == prodId) {
                            prod = updatedProduct;
                            break;
                        }
                    }
                    saveJson(data);
                    response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\n\r\nOK";
                    std::cout << "Обновлен товар (ID: " << prodId << ")" << std::endl;
                }
                catch (const std::exception& ex) {
                    std::cerr << "Ошибка при обновлении товара: " << ex.what() << std::endl;
                    response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                }
            }
            // Удаление товара
            else if (path == "/deleteProduct") {
                try {
                    json delReq = json::parse(body);
                    std::ifstream inFile("data.json");
                    json data;
                    inFile >> data;
                    inFile.close();
                    if (!delReq.is_object() || !delReq.contains("id")) {
                        throw std::runtime_error("Некорректный формат запроса удаления");
                    }
                    int prodId = delReq["id"];
                    if (!data.contains("products")) {
                        data["products"] = json::array();
                    }
                    // Удаляем товар с заданным ID
                    auto& prodArray = data["products"];
                    prodArray.erase(std::remove_if(prodArray.begin(), prodArray.end(),
                        [&](const json& p) {
                            return p.contains("id") && p["id"] == prodId;
                        }),
                        prodArray.end());
                    saveJson(data);
                    response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 7\r\n\r\nDeleted";
                    std::cout << "Удален товар (ID: " << prodId << ")" << std::endl;
                }
                catch (const std::exception& ex) {
                    std::cerr << "Ошибка при удалении товара: " << ex.what() << std::endl;
                    response = "HTTP/1.1 500 Internal Server Error\r\n\r\n";
                }
            }
            else {
                // Неизвестный путь в POST запросе
                response = "HTTP/1.1 404 Not Found\r\n\r\n";
            }
        }
        else {
            // Неподдерживаемый метод
            response = "HTTP/1.1 400 Bad Request\r\n\r\n";
        }

        // Отправляем ответ клиенту
        send(ClientSocket, response.c_str(), (int)response.size(), 0);
        closesocket(ClientSocket);
    }

    // Завершение работы Winsock (не достигнется в данном коде)
    WSACleanup();
    return 0;
}
